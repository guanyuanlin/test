if [ ! -f "./bak/blacklist.conf" ];then
  echo "blacklist.conf not exist,no need to move"
else 
  cp -r ./bak/blacklist.conf   /etc/modprobe.d/blacklist.conf -rf
  echo "blacklist.conf move success"
fi

mv /etc/default  /etc/default.bak && echo "/etc/default/ move success"
#mkdir /etc/default/


if [ ! -d "./bak/default" ];then
  echo "default not exist,no need to move"
else 
  cp -rf ./bak/default/*   /etc/default/ 
  echo "default folder move success"
fi
